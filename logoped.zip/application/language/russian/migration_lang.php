<?php

$lang['config_corrupted'] = 'Migrations Config file is corrupted';
$lang['invalid_migration_filename'] = 'Invalid migration file name, "%s".';
$lang['migration_class_doesnt_exist'] = 'Migration class doesn\'t exist: "%s".';
$lang['migration_not_found'] = 'Migration %d not found.';
$lang['multiple_migrations_name'] = 'Multiple migrations have the name %s.';
$lang['multiple_migrations_version'] = 'Multiple migrations have version number %d.';
$lang['must_call'] = 'Must call migrate/version/version_number';
$lang['no_migrations_found'] = 'No migrations found';
$lang['wrong_migration_interface'] = '"%s" has a wrong insterface.<br /> Migrations should implement both public static methods "up" and "down"';

?>