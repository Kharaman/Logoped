<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Children_groups_model extends MY_model
{
    protected static $table = 'children_groups';

}