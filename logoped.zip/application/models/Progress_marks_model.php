<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Progress_marks_model extends MY_model
{
    protected static $table = 'progress_marks';

}