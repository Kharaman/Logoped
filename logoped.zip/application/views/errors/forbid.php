<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<h3 class="center-align">У вас нет прав для доступа к этой странице</h3>
<p class="center-align">
    Свяжитесь с администратором для более детальной информации
</p>