<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
</main>
</div>
<footer>

</footer>
</div>
<div class="mask"></div>
<!-- Modal Structure -->
<div id="modal-exit" class="modal">
    <div class="modal-content">
        <h4>Выход</h4>
        <p>Вы уверены что хотите выйти?</p>
    </div>
    <div class="modal-footer">
    <a href="#!" class="modal-action modal-close waves-effect btn-flat">Отмена</a>
        <a href="/auth/logout" class="modal-action modal-close waves-effect btn-flat">OK</a>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.3/jquery.min.js"></script>
<script src="/js/script.min.js"></script>
</body>
</html>